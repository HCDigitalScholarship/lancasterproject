<?php
require_once 'ImageResizePlugin.php';
$imageResizePlugin = new ImageResizePlugin;
$imageResizePlugin->setUp();
