## Clear all Geometry

This button is similar to "Delete Shape," but it delete _all_ vector annotations for the record. This can be useful when you've made a mistake of some sort (for example, when experimenting with different ways of positioning an imported SVG document) and want to just completely clear out your work.
