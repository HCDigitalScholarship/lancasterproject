## Fill Opacity

The opacity of the "body" of points and polygons on the map - the area inside the lines, not including the lines themselves. 

To change the opacity, type directly into the input or change the value smoothly down by clicking and moving the mouse up or down on the page.

  - Min: `0.00`
  - Max: `1.00`
