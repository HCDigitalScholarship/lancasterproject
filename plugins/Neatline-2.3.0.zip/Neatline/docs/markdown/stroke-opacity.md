## Stroke Opacity

The opacity of the lines that run around the edges of shapes on the map.

To change the opacity, type directly into the input or change the value smoothly down by clicking and moving the mouse up or down on the page.

  - Min: `0.00`
  - Max: `1.00`
