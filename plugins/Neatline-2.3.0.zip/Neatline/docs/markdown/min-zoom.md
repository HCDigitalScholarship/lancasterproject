## Min Zoom

The zoom level "above" which the record will be visible, with zooming "in" being "higher" (eg, focusing on Spain is "higher" than focusing on Europe). For example, if the record has a point on the map and "Min Zoom" is `10`, then the point will be invisible when the map at zoom level `9`, and will become visible as soon as the map zooms to `10`.

To set the value, just zoom the map the the level that you want to use for the value, and click the "Use Current" button next to the field title to automatically insert the current zoom offset into the input.
