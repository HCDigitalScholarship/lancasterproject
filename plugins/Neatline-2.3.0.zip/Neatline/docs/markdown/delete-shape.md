## Delete Shape

Delete an existing point, line, or polygon.

  1. Select the "Delete Shape" radio button.

  2. To delete a shape, just click once on the shape, and it will immediately be removed from the map.
