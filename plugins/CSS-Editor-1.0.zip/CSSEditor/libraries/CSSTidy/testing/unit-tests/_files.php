<?php

$test_files = array();
$test_files[] = 'test.csst.php';
